#import libreriaPablito # preserva (NO mezcla) los namespaces
#n = libreriaPablito.inputInt("Ingrese un entero: ")
#print(libreriaPablito.foo())

# from libreriaPablito import * # con * trae todas las funciones al namespace de main
from libs.libreriaPablito import foo 
from libs.valids import inputFloat, inputInt # trae las funciones individualmente
from libs.calculo_edad import edad
n = inputInt("Ingrese un entero: ")
print("El entero ingresado es", n)
print(foo())
print(edad("01-01-2000"))



