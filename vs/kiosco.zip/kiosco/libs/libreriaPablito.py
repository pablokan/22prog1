def bar():
    return "bar"

def foo():
    return "foo de la libreria pablito"

