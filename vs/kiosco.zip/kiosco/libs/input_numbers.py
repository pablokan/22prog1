# Modificar la función inputInt por inputNumber que tenga un parámetro adicional para seleccionar
# si quiero un entero o bien un real

