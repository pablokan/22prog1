def suma(n1, n2): # ejemplo con parámetros posicionales
    print(n1 + n2)

suma(3, 4) # debe respetarse cantidad

def sumaV(*args): # parámetro tupla para cantidad variable de argumentos
    print(args) # muestra la tupla enviada como argumento
    t = 0
    for x in range(len(args)):
        t += args[x]
    return t

print(sumaV(1,2,3,4,5,6,7))
print(sumaV(33, 2))

